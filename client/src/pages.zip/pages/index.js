export { default } from "./Info.js";
